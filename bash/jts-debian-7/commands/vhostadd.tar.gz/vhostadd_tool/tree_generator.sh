#!/bin/bash
#===============================================================================
#    vhostadd for JackTheStripper v 2.5
#    Official Version for deploy a Debian GNU/Linux server, version 7 (or more)

#    Developed by Eugenia Bahit <eugenia@linux.com>
#    
#    Copyright © 2013, 2014, 2015 Eugenia Bahit <eugenia@linux.com>
#    License: GNU GPL version 3  <http://gnu.org/licenses/gpl.html>.
#    This is free software: you are free to change and redistribute it.
#    There is NO WARRANTY, to the extent permitted by law.
#===============================================================================

mkdir -p /srv/websites/$1/{application,logs,$2}
bzr init-repo /srv/websites/$1/
bzr init /srv/websites/$1/application
