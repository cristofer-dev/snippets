# -*- coding: utf-8 -*-
#===============================================================================
#    vhostadd for JackTheStripper v 2.5
#    Official Version for deploy a Debian GNU/Linux server, version 7 (or more)

#    Developed by Eugenia Bahit <eugenia@linux.com>
#    
#    Copyright © 2013, 2014, 2015 Eugenia Bahit <eugenia@linux.com>
#    License: GNU GPL version 3  <http://gnu.org/licenses/gpl.html>.
#    This is free software: you are free to change and redistribute it.
#    There is NO WARRANTY, to the extent permitted by law.
#===============================================================================

from sys import path
path.append(__file__.replace('/controller.py', ''))


def application(environ, start_response):
    salida = "Hello <b>Python</b> World!"
    start_response('200 OK', [('Content-Type', 'text/html; charset=utf8')])
    return salida
