<?php
header('Content-Type: text/html; charset=utf8');
print "Hello <b>PHP</b> World!";
?>
